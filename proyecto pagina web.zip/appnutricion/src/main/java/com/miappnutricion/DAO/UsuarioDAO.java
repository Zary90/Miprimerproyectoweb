package com.miappnutricion.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.miapp.modelo.Usuario;

public class UsuarioDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/miappdb";
    private String jdbcUsername = "root";
    private String jdbccontraseña = "contraseña";
	private String DELETE_USUARIO_SQL;

    private static final String INSERT_USUARIOS_SQL = "INSERT INTO usuarios (nombre, apellidos, email, contraseña) VALUES (?, ?, ?);";
    private static final String SELECT_ALL_USUARIOS = "SELECT * FROM usuarios;";
	private static final String DELETE_USUARIO_SQL1 = null;

    /**
     * Esto es una clase Dao para gestionar la tabla usuario
     */ 
     
    public UsuarioDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbccontraseña);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
    
    /*
     * Método que se encarga de insertar un nuevo usuario en la base de datos
     * @throw SQLException se utiliza por si al insertar un nuevo usuario en BBD hay un error
     * 
     */

    public void registrarUsuario(Usuario usuario) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USUARIOS_SQL)) {
            preparedStatement.setString(1, usuario.getNombre());
            preparedStatement.setString(2, usuario.getapellidos());
            preparedStatement.setString(3, usuario.getEmail());
            preparedStatement.setString(4, usuario.getcontraseña());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al registrar el usuario", e);
        }
    }

    
    /*
     * Método que se encarga de eliminar a un usuario
     * @throw new SQLException se utiliza cuando se quiere eliminar un usuario y da error
     * 
     */
    public void eliminarUsuario(String email) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_USUARIO_SQL1)) {
            preparedStatement.setString(1, email);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("No se pudo eliminar el usuario con email: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al eliminar el usuario", e);
        }
    }
    
    
    
   /*
    * Método que obtiene una lista de usuarios desde la base de datos
    * @return recuperar el valor de un campo privado en una clase en este caso el usuario
    * 
    */
    public List<Usuario> obtenerTodosLosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USUARIOS)) {
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String email = rs.getString("email");
                String contraseña = rs.getString("contraseña");
                usuarios.add(new Usuario(nombre, apellidos, email, contraseña));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }
}

   