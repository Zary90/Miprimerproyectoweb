package com.miappnutricion.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/* 
 * Esta clase DBConnection proporciona una forma sencilla y directa de conectar la aplicación Java 
 * a la base de datos MySQL utilizando JDBC y propiedades.
 */

public class DBConnection {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/miappdb";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "888888888";

    public static Connection getConnection() throws SQLException {
        Properties props = new Properties();
        props.put("user", JDBC_USER);
        props.put("password", JDBC_PASSWORD);
        props.put("useUnicode", "true");
        props.put("characterEncoding", "UTF-8");

        return DriverManager.getConnection(JDBC_URL, props);
    }
}

	   
