package com.miapp.servlet;


import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletFormularioRegistroUsuario;
import com.miappnutricion.DAO.UsuarioDAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.miapp.modelo.Usuario;


/**
 * @WebServlet("/registrarUsuario")
 * Crear un Servlet para manejar el registro de usuarios
 */

public class RegistroServlet extends HttpServletFormularioRegistroUsuario {
    private static final long serialVersionUID = 1L;
    private UsuarioDAO usuarioDAO;

    public void init() {
        usuarioDAO = new UsuarioDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellidos = request.getParameter("apellidos");
        String email = request.getParameter("email");
        String contraseña = request.getParameter("contraseña");
        
/* 
 * Registro de nuevos usuarios
 * @response mensaje directo al finalizar el registro usuario 
 */

        Usuario nuevoUsuario = new Usuario(nombre, apellidos, email, contraseña);

        try {
            usuarioDAO.registrarUsuario(nuevoUsuario);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("registro-exitoso.html");
    }

	public static long getSerialversionuid() {
		return serialVersionUID; }
}
