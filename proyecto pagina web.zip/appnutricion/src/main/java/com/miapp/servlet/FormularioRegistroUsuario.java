package com.miapp.servlet;

import java.io.IOException;
import java.sql.SQLException;

import com.miapp.modelo.Usuario;
import com.miappnutricion.DAO.UsuarioDAO;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/registrarUsuario")
public class FormularioRegistroUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UsuarioDAO usuarioDAO;

    public void init() {
        usuarioDAO = new UsuarioDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
    
        /**
         * 
         *  Obtener los parámetros del formulario
         */
    	
        String nombre = request.getParameter("nombre");
        String apellidos = request.getParameter("apellidos");
        String email = request.getParameter("email");
        String contraseña = request.getParameter("contraseña");

        /*
         *  Crear un nuevo objeto Usuario
         */
        
        Usuario nuevoUsuario = new Usuario(nombre, apellidos, email, contraseña);

        /*
         * Intentar registrar el usuario utilizando UsuarioDAO
         */
        
        try {
            usuarioDAO.registrarUsuario(nuevoUsuario);
            /*
             * 
             *  Redirigir a una página de éxito
             */
            
            response.sendRedirect("registro-exitoso.html");
        } catch (SQLException e) {
            e.printStackTrace();
            /*
             * 
             *  Redirigir a una página de error
             */
            
            response.sendRedirect("registro-error.html");
        }
    }
}
