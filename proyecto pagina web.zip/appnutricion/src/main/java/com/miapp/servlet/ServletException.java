package com.miapp.servlet;

public class ServletException extends Exception {

}
